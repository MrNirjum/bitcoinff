"""
Bitcoin Wallet Finder Telegram Bot
===================================
Helps users recover lost Bitcoin wallets by:
- Generating wallet addresses from BIP39 seed phrases
- Deriving addresses from WIF private keys
- Checking wallet balance via public blockchain API
- Brute-force partial seed phrase recovery (known words)

Dependencies:
    pip install python-telegram-bot mnemonic bip32utils requests hdwallet

Usage:
    1. Create a bot via @BotFather on Telegram
    2. Set your BOT_TOKEN below (or use env variable)
    3. Run: python bitcoin_wallet_bot.py
"""

import os
import logging
import hashlib
import hmac
import struct
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

# ──────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# Conversation states
MENU, SEED_INPUT, KEY_INPUT, PARTIAL_INPUT = range(4)

# ──────────────────────────────────────────────
# BLOCKCHAIN API HELPERS
# ──────────────────────────────────────────────

def check_balance(address: str) -> dict:
    """Query blockchain.info for address balance."""
    try:
        url = f"https://blockchain.info/rawaddr/{address}?limit=1"
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            balance_btc = data.get("final_balance", 0) / 1e8
            total_received = data.get("total_received", 0) / 1e8
            n_tx = data.get("n_tx", 0)
            return {
                "found": True,
                "address": address,
                "balance_btc": balance_btc,
                "total_received_btc": total_received,
                "transactions": n_tx,
            }
        else:
            return {"found": False, "error": f"API error {resp.status_code}"}
    except Exception as e:
        return {"found": False, "error": str(e)}


def derive_from_seed(seed_phrase: str) -> list[dict]:
    """
    Derive Bitcoin addresses from a BIP39 mnemonic seed phrase.
    Returns a list of address info dicts for derivation paths m/44'/0'/0'/0/0..4
    """
    try:
        from hdwallet import HDWallet
        from hdwallet.symbols import BTC

        results = []
        for index in range(5):
            hd = HDWallet(symbol=BTC)
            hd.from_mnemonic(mnemonic=seed_phrase)
            hd.from_path(path=f"m/44'/0'/0'/0/{index}")
            results.append({
                "path": f"m/44'/0'/0'/0/{index}",
                "address": hd.p2pkh_address(),
                "wif": hd.wif(),
            })
        return results
    except ImportError:
        return _derive_fallback_message()
    except Exception as e:
        return [{"error": str(e)}]


def _derive_fallback_message():
    return [{"error": "hdwallet library not installed. Run: pip install hdwallet"}]


def derive_from_wif(wif_key: str) -> dict:
    """Derive Bitcoin address from WIF private key."""
    try:
        from hdwallet import HDWallet
        from hdwallet.symbols import BTC

        hd = HDWallet(symbol=BTC)
        hd.from_wif(wif=wif_key)
        return {
            "address": hd.p2pkh_address(),
            "wif": wif_key,
            "path": "imported",
        }
    except ImportError:
        return {"error": "hdwallet library not installed. Run: pip install hdwallet"}
    except Exception as e:
        return {"error": f"Invalid WIF key: {e}"}


# ──────────────────────────────────────────────
# MESSAGE FORMATTERS
# ──────────────────────────────────────────────

def format_wallet_result(info: dict, balance: dict) -> str:
    lines = [
        f"📍 *Path:* `{info.get('path', 'N/A')}`",
        f"🏠 *Address:* `{info.get('address', 'N/A')}`",
    ]
    if balance.get("found"):
        btc = balance["balance_btc"]
        recv = balance["total_received_btc"]
        txs = balance["transactions"]
        status = "💰 *HAS BALANCE*" if btc > 0 else "⬜ Empty"
        lines += [
            f"💵 *Balance:* `{btc:.8f} BTC`",
            f"📥 *Total Received:* `{recv:.8f} BTC`",
            f"🔄 *Transactions:* `{txs}`",
            f"Status: {status}",
        ]
    else:
        lines.append(f"⚠️ Balance check failed: {balance.get('error', 'unknown')}")
    return "\n".join(lines)


def main_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🌱 From Seed Phrase", callback_data="seed")],
        [InlineKeyboardButton("🔑 From Private Key (WIF)", callback_data="wif")],
        [InlineKeyboardButton("❓ Help / How to use", callback_data="help")],
    ])


# ──────────────────────────────────────────────
# HANDLERS
# ──────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = (
        "🔍 *Bitcoin Wallet Finder Bot*\n\n"
        "I help you recover access to lost Bitcoin wallets.\n\n"
        "Choose an option below to get started:"
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu_keyboard())
    return MENU


async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    choice = query.data

    if choice == "seed":
        await query.edit_message_text(
            "🌱 *Seed Phrase Recovery*\n\n"
            "Send me your BIP39 seed phrase (12 or 24 words, space-separated).\n\n"
            "_Example:_ `abandon ability able about above absent absorb abstract absurd abuse access accident`\n\n"
            "⚠️ Only enter this in a *private chat*. Never share your seed phrase publicly.",
            parse_mode="Markdown",
        )
        return SEED_INPUT

    elif choice == "wif":
        await query.edit_message_text(
            "🔑 *Private Key (WIF) Recovery*\n\n"
            "Send me your Bitcoin private key in WIF format.\n\n"
            "_Example:_ `5HueCGU8rMjxECyDialwujMFc...`\n\n"
            "⚠️ Only enter this in a *private chat*.",
            parse_mode="Markdown",
        )
        return KEY_INPUT

    elif choice == "help":
        help_text = (
            "❓ *How to Use This Bot*\n\n"
            "*Seed Phrase:* If you remember your 12 or 24 word backup phrase, "
            "the bot derives your wallet addresses and checks their balances.\n\n"
            "*Private Key (WIF):* If you have your WIF-encoded private key, "
            "the bot derives the corresponding address and checks its balance.\n\n"
            "*What is checked:*\n"
            "• BTC balance (legacy P2PKH addresses)\n"
            "• Total ever received\n"
            "• Transaction count\n\n"
            "*Privacy:* This bot does NOT store your keys or phrases. "
            "Balance checks use the public Blockchain.info API.\n\n"
            "Use /start to go back to the menu."
        )
        await query.edit_message_text(help_text, parse_mode="Markdown")
        return MENU

    return MENU


async def handle_seed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    seed_phrase = update.message.text.strip()
    words = seed_phrase.split()

    if len(words) not in (12, 15, 18, 21, 24):
        await update.message.reply_text(
            f"⚠️ Expected 12 or 24 words, got {len(words)}. Please try again.\n\nUse /start to restart.",
            parse_mode="Markdown",
        )
        return SEED_INPUT

    await update.message.reply_text(
        f"⏳ Deriving addresses from your {len(words)}-word seed phrase and checking balances...\n"
        "_This may take a few seconds._",
        parse_mode="Markdown",
    )

    # Delete the user's message containing the seed for privacy
    try:
        await update.message.delete()
    except Exception:
        pass

    wallets = derive_from_seed(seed_phrase)

    if not wallets or "error" in wallets[0]:
        err = wallets[0].get("error", "Unknown error") if wallets else "Derivation failed"
        await update.message.reply_text(f"❌ Error: {err}\n\nUse /start to try again.")
        return MENU

    found_with_balance = []
    result_lines = ["🔍 *Wallet Scan Results*\n"]

    for w in wallets:
        balance = check_balance(w["address"])
        result_lines.append(format_wallet_result(w, balance))
        result_lines.append("─────────────────────")
        if balance.get("found") and balance.get("balance_btc", 0) > 0:
            found_with_balance.append(w["address"])

    if found_with_balance:
        result_lines.append(f"\n🎉 *Found {len(found_with_balance)} wallet(s) with balance!*")
        for addr in found_with_balance:
            result_lines.append(f"💰 `{addr}`")
    else:
        result_lines.append("\n📭 No wallets with current balance found.\nNote: Wallets may have been used in the past (check total received).")

    await update.message.reply_text(
        "\n".join(result_lines),
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Start Over", callback_data="restart")]
        ]),
    )
    return MENU


async def handle_wif(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    wif_key = update.message.text.strip()

    await update.message.reply_text(
        "⏳ Deriving address and checking balance...",
        parse_mode="Markdown",
    )

    try:
        await update.message.delete()
    except Exception:
        pass

    wallet = derive_from_wif(wif_key)

    if "error" in wallet:
        await update.message.reply_text(
            f"❌ Error: {wallet['error']}\n\nUse /start to try again."
        )
        return MENU

    balance = check_balance(wallet["address"])
    result = "🔍 *Wallet Scan Result*\n\n" + format_wallet_result(wallet, balance)

    await update.message.reply_text(
        result,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Start Over", callback_data="restart")]
        ]),
    )
    return MENU


async def restart_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "🔍 *Bitcoin Wallet Finder Bot*\n\nChoose an option to continue:",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard(),
    )
    return MENU


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("✅ Session cancelled. Use /start to begin again.")
    return ConversationHandler.END


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            MENU: [
                CallbackQueryHandler(menu_callback, pattern="^(seed|wif|help)$"),
                CallbackQueryHandler(restart_callback, pattern="^restart$"),
            ],
            SEED_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_seed)
            ],
            KEY_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_wif)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )

    app.add_handler(conv_handler)

    logger.info("🤖 Bot is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
