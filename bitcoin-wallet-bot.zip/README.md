# 🔍 Bitcoin Wallet Finder — Telegram Bot

A Telegram bot to help recover lost Bitcoin wallets from seed phrases or WIF private keys.

---

## Features

- ✅ Derive wallet addresses from BIP39 seed phrases (12 or 24 words)
- ✅ Derive address from WIF-encoded private key
- ✅ Check live balance via Blockchain.info public API
- ✅ Shows total received & transaction count
- ✅ Automatically deletes messages containing sensitive keys for privacy
- ✅ Clean inline keyboard UI

---

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Create a Telegram bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot` and follow the prompts
3. Copy the **API token** you receive

### 3. Set your bot token

Either edit `bitcoin_wallet_bot.py` and replace:
```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
```

Or set an environment variable:
```bash
export TELEGRAM_BOT_TOKEN="your_token_here"
```

### 4. Run the bot

```bash
python bitcoin_wallet_bot.py
```

---

## Usage

In your Telegram chat with the bot:

| Command | Description |
|---------|-------------|
| `/start` | Open the main menu |
| `/cancel` | Cancel current session |

### Seed Phrase Recovery
Send a 12 or 24 word BIP39 mnemonic. The bot derives the first 5 addresses on the standard path `m/44'/0'/0'/0/0–4` and checks each for balance.

### Private Key (WIF) Recovery
Send your WIF-formatted private key. The bot derives the corresponding address and checks its balance.

---

## Privacy Notes

- The bot **deletes your message** containing the seed/key immediately after reading it
- Keys and phrases are **never stored** anywhere
- Balance checks use the **public Blockchain.info API** (no account needed)

---

## Disclaimer

This tool is intended for recovering your own lost wallets only. Always run this bot in a **private chat**, never in groups.
